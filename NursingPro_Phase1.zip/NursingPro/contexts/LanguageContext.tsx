import React, { createContext, useContext, useMemo, useState } from "react";

type Language = "en" | "ar";
type Dictionary = Record<string, { en: string; ar: string }>;

const dictionary: Dictionary = {
  welcome: { en: "Welcome back", ar: "مرحبًا بعودتك" },
  signInSubtitle: { en: "Sign in to access your clinical workspace.", ar: "سجّل الدخول للوصول إلى مساحة العمل." },
  email: { en: "Email address", ar: "البريد الإلكتروني" },
  password: { en: "Password", ar: "كلمة المرور" },
  signIn: { en: "Sign in", ar: "تسجيل الدخول" },
  demoNotice: { en: "Prototype preview: secure authentication will be connected in Phase 4.", ar: "نسخة تجريبية: سيتم ربط تسجيل الدخول الآمن في المرحلة الرابعة." },
  footer: { en: "Designed for coordinated clinical teams.", ar: "مصمم لفرق الرعاية الصحية المتكاملة." },
  missingTitle: { en: "Missing information", ar: "بيانات ناقصة" },
  missingFields: { en: "Enter your email and password to continue.", ar: "أدخل البريد الإلكتروني وكلمة المرور للمتابعة." },
  invalidTitle: { en: "Invalid email", ar: "بريد إلكتروني غير صحيح" },
  invalidEmail: { en: "Enter a valid email address.", ar: "أدخل عنوان بريد إلكتروني صحيحًا." },
  phaseTitle: { en: "Phase 1 preview", ar: "معاينة المرحلة الأولى" },
  phaseMessage: { en: "The interface is ready. Real sign-in will be enabled after Supabase setup.", ar: "الواجهة جاهزة. سيتم تفعيل تسجيل الدخول الحقيقي بعد إعداد Supabase." }
};

type LanguageContextValue = {
  language: Language;
  setLanguage: (language: Language) => void;
  isRTL: boolean;
  t: (key: string) => string;
};

const LanguageContext = createContext<LanguageContextValue | null>(null);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>("en");
  const value = useMemo<LanguageContextValue>(() => ({
    language,
    setLanguage,
    isRTL: language === "ar",
    t: (key: string) => dictionary[key]?.[language] ?? key
  }), [language]);

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) throw new Error("useLanguage must be used inside LanguageProvider");
  return context;
}
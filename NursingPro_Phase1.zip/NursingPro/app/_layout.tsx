import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { LanguageProvider } from "../contexts/LanguageContext";
import { colors } from "../constants/colors";

export default function RootLayout() {
  return (
    <LanguageProvider>
      <StatusBar style="dark" backgroundColor={colors.background} />
      <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.background } }}>
        <Stack.Screen name="index" />
        <Stack.Screen name="login" />
      </Stack>
    </LanguageProvider>
  );
}
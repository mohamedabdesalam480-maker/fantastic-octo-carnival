import { useEffect, useRef } from "react";
import { Animated, Easing, StyleSheet, Text, View } from "react-native";
import { router } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import { colors } from "../constants/colors";

function MedicalScene() {
  const pulse = useRef(new Animated.Value(0.92)).current;
  const orbit = useRef(new Animated.Value(0)).current;
  const float = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const pulseLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1.06, duration: 1150, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 0.92, duration: 1150, easing: Easing.inOut(Easing.ease), useNativeDriver: true })
      ])
    );
    const orbitLoop = Animated.loop(Animated.timing(orbit, { toValue: 1, duration: 6500, easing: Easing.linear, useNativeDriver: true }));
    const floatLoop = Animated.loop(Animated.sequence([
      Animated.timing(float, { toValue: -12, duration: 1500, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
      Animated.timing(float, { toValue: 0, duration: 1500, easing: Easing.inOut(Easing.ease), useNativeDriver: true })
    ]));
    pulseLoop.start(); orbitLoop.start(); floatLoop.start();
    return () => { pulseLoop.stop(); orbitLoop.stop(); floatLoop.stop(); };
  }, [pulse, orbit, float]);

  const rotate = orbit.interpolate({ inputRange: [0, 1], outputRange: ["0deg", "360deg"] });

  return (
    <View style={styles.scene}>
      <View style={styles.glow} />
      <Animated.View style={[styles.orbit, { transform: [{ rotate }] }]}>
        <View style={styles.orbitDot} />
      </Animated.View>
      <Animated.View style={[styles.medicalCard, { transform: [{ translateY: float }, { perspective: 900 }, { rotateX: "10deg" }, { rotateY: "-12deg" }, { scale: pulse }] }]}>
        <View style={styles.cardTop}>
          <View style={styles.miniMark}><Text style={styles.miniMarkText}>+</Text></View>
          <View style={styles.cardLines}><View style={styles.lineLong} /><View style={styles.lineShort} /></View>
          <View style={styles.statusDot} />
        </View>
        <View style={styles.crossWrap}><View style={styles.crossV} /><View style={styles.crossH} /></View>
        <View style={styles.cardBottom}>
          <View style={styles.pulseLine}><Text style={styles.pulseText}>⌁  ♥  ⌁</Text></View>
          <Text style={styles.cardCaption}>CARE • TEAM • TRUST</Text>
        </View>
      </Animated.View>
      <View style={styles.smallOrb}><Text style={styles.smallOrbText}>✚</Text></View>
      <View style={styles.smallOrbTwo}><Text style={styles.smallOrbText}>♡</Text></View>
    </View>
  );
}

export default function IntroScreen() {
  useEffect(() => {
    const timer = setTimeout(() => router.replace("/login"), 3200);
    return () => clearTimeout(timer);
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.brandRow}>
        <View style={styles.brandIcon}><Text style={styles.brandPlus}>+</Text></View>
        <Text style={styles.brandName}>NURSING<Text style={styles.brandAccent}> PRO</Text></Text>
      </View>
      <View style={styles.center}>
        <MedicalScene />
        <Text style={styles.headline}>Care, connected.</Text>
        <Text style={styles.subtitle}>A smarter way to coordinate clinical teams.</Text>
      </View>
      <View style={styles.footer}>
        <View style={styles.loadingTrack}><View style={styles.loadingFill} /></View>
        <Text style={styles.footerText}>HOSPITAL WORKFLOW • MADE CLEAR</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, paddingHorizontal: 26, justifyContent: "space-between" },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 11, paddingTop: 18 },
  brandIcon: { width: 38, height: 38, borderRadius: 13, backgroundColor: colors.navy, alignItems: "center", justifyContent: "center" },
  brandPlus: { color: "#FFFFFF", fontSize: 29, fontWeight: "300", lineHeight: 32 },
  brandName: { color: colors.navy, fontSize: 17, letterSpacing: 1.8, fontWeight: "800" },
  brandAccent: { color: colors.blue },
  center: { alignItems: "center", marginTop: -24 },
  scene: { width: 290, height: 300, alignItems: "center", justifyContent: "center" },
  glow: { position: "absolute", width: 230, height: 230, borderRadius: 115, backgroundColor: "#E3EEF9" },
  orbit: { position: "absolute", width: 265, height: 190, borderRadius: 130, borderWidth: 1, borderColor: "#C7D9EB", alignItems: "flex-start", justifyContent: "center" },
  orbitDot: { width: 12, height: 12, borderRadius: 6, backgroundColor: colors.blue, marginLeft: -6 },
  medicalCard: { width: 190, height: 220, borderRadius: 28, backgroundColor: colors.navy, padding: 18, justifyContent: "space-between", shadowColor: "#102A4C", shadowOpacity: 0.24, shadowRadius: 25, shadowOffset: { width: 0, height: 18 }, elevation: 12 },
  cardTop: { flexDirection: "row", alignItems: "center", gap: 9 },
  miniMark: { width: 27, height: 27, borderRadius: 9, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center" },
  miniMarkText: { color: colors.navy, fontSize: 23, fontWeight: "500", lineHeight: 26 },
  cardLines: { flex: 1, gap: 5 },
  lineLong: { width: 68, height: 5, borderRadius: 3, backgroundColor: "#AFC6DE" },
  lineShort: { width: 43, height: 4, borderRadius: 3, backgroundColor: "#6F91B5" },
  statusDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: "#6EE7B7" },
  crossWrap: { alignSelf: "center", width: 82, height: 82, alignItems: "center", justifyContent: "center" },
  crossV: { position: "absolute", width: 25, height: 82, borderRadius: 8, backgroundColor: "#FFFFFF" },
  crossH: { position: "absolute", width: 82, height: 25, borderRadius: 8, backgroundColor: "#FFFFFF" },
  cardBottom: { alignItems: "center", gap: 5 },
  pulseLine: { width: "100%", height: 25, borderRadius: 8, backgroundColor: "#193D67", alignItems: "center", justifyContent: "center" },
  pulseText: { color: "#9ED8FF", fontSize: 17, fontWeight: "700" },
  cardCaption: { color: "#B7CBE0", fontSize: 8, letterSpacing: 1.5, fontWeight: "700" },
  smallOrb: { position: "absolute", right: 22, top: 48, width: 43, height: 43, borderRadius: 14, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center", elevation: 5, shadowColor: "#173B63", shadowOpacity: 0.12, shadowRadius: 10 },
  smallOrbTwo: { position: "absolute", left: 20, bottom: 45, width: 38, height: 38, borderRadius: 13, backgroundColor: "#DCEBFA", alignItems: "center", justifyContent: "center" },
  smallOrbText: { color: colors.blue, fontSize: 20, fontWeight: "800" },
  headline: { marginTop: 4, color: colors.navy, fontSize: 28, fontWeight: "800", letterSpacing: -0.7 },
  subtitle: { marginTop: 9, color: colors.muted, fontSize: 13, textAlign: "center" },
  footer: { alignItems: "center", paddingBottom: 22, gap: 12 },
  loadingTrack: { width: 86, height: 4, borderRadius: 3, backgroundColor: "#DCE6F0", overflow: "hidden" },
  loadingFill: { width: "65%", height: 4, backgroundColor: colors.blue, borderRadius: 3 },
  footerText: { color: "#91A3B7", fontSize: 9, letterSpacing: 1.8, fontWeight: "700" }
});
import { useState } from "react";
import { Alert, KeyboardAvoidingView, Platform, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useLanguage } from "../contexts/LanguageContext";
import { colors } from "../constants/colors";

export default function LoginScreen() {
  const { language, setLanguage, t, isRTL } = useLanguage();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  function handleContinue() {
    if (!email.trim() || !password) {
      Alert.alert(t("missingTitle"), t("missingFields"));
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      Alert.alert(t("invalidTitle"), t("invalidEmail"));
      return;
    }
    Alert.alert(t("phaseTitle"), t("phaseMessage"));
  }

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <View style={[styles.topBar, isRTL && styles.rowRTL]}>
          <View style={styles.brandRow}>
            <View style={styles.brandIcon}><Text style={styles.brandPlus}>+</Text></View>
            <Text style={styles.brandName}>NURSING<Text style={styles.brandAccent}> PRO</Text></Text>
          </View>
          <Pressable onPress={() => setLanguage(language === "en" ? "ar" : "en")} style={styles.languageButton}>
            <Text style={styles.languageText}>{language === "en" ? "عربي" : "English"}</Text>
          </Pressable>
        </View>

        <View style={styles.hero}>
          <View style={styles.heroIcon}><Text style={styles.heroPlus}>+</Text></View>
          <Text style={[styles.title, isRTL && styles.textRTL]}>{t("welcome")}</Text>
          <Text style={[styles.subtitle, isRTL && styles.textRTL]}>{t("signInSubtitle")}</Text>
        </View>

        <View style={styles.form}>
          <Text style={[styles.label, isRTL && styles.textRTL]}>{t("email")}</Text>
          <TextInput
            value={email}
            onChangeText={setEmail}
            placeholder="name@hospital.com"
            placeholderTextColor="#9AAABD"
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            textContentType="emailAddress"
            style={[styles.input, isRTL && styles.inputRTL]}
          />
          <Text style={[styles.label, isRTL && styles.textRTL]}>{t("password")}</Text>
          <TextInput
            value={password}
            onChangeText={setPassword}
            placeholder="••••••••"
            placeholderTextColor="#9AAABD"
            secureTextEntry
            autoCapitalize="none"
            textContentType="password"
            style={styles.input}
          />
          <Pressable onPress={handleContinue} style={({ pressed }) => [styles.button, pressed && styles.buttonPressed]}>
            <Text style={styles.buttonText}>{t("signIn")}</Text>
            <Text style={styles.buttonArrow}>{isRTL ? "←" : "→"}</Text>
          </Pressable>
          <Text style={styles.helper}>{t("demoNotice")}</Text>
        </View>

        <View style={styles.bottom}>
          <Text style={styles.bottomText}>NURSING PRO • VERSION 1.0.0</Text>
          <Text style={styles.bottomSub}>{t("footer")}</Text>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  container: { flex: 1, paddingHorizontal: 25, justifyContent: "space-between", paddingBottom: 18 },
  topBar: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingTop: 10 },
  rowRTL: { flexDirection: "row-reverse" },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 9 },
  brandIcon: { width: 34, height: 34, borderRadius: 11, backgroundColor: colors.navy, alignItems: "center", justifyContent: "center" },
  brandPlus: { color: "#FFFFFF", fontSize: 26, lineHeight: 29, fontWeight: "300" },
  brandName: { color: colors.navy, fontSize: 14, letterSpacing: 1.3, fontWeight: "800" },
  brandAccent: { color: colors.blue },
  languageButton: { borderWidth: 1, borderColor: colors.border, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, backgroundColor: "#FFFFFF" },
  languageText: { color: colors.navy, fontWeight: "700", fontSize: 12 },
  hero: { alignItems: "center", marginTop: 20 },
  heroIcon: { width: 70, height: 70, borderRadius: 23, backgroundColor: colors.paleBlue, alignItems: "center", justifyContent: "center", marginBottom: 20 },
  heroPlus: { color: colors.blue, fontSize: 54, lineHeight: 59, fontWeight: "300" },
  title: { color: colors.navy, fontSize: 29, fontWeight: "800", letterSpacing: -0.7 },
  subtitle: { color: colors.muted, fontSize: 13, marginTop: 8, textAlign: "center", lineHeight: 20 },
  form: { gap: 10, marginTop: 10 },
  label: { color: colors.navy, fontWeight: "700", fontSize: 13, marginTop: 8 },
  textRTL: { textAlign: "right", alignSelf: "stretch" },
  input: { height: 54, borderWidth: 1, borderColor: colors.border, borderRadius: 14, paddingHorizontal: 16, backgroundColor: "#FFFFFF", color: colors.text, fontSize: 14 },
  inputRTL: { textAlign: "right" },
  button: { height: 55, borderRadius: 15, backgroundColor: colors.navy, alignItems: "center", justifyContent: "center", flexDirection: "row", marginTop: 15, gap: 12 },
  buttonPressed: { opacity: 0.86, transform: [{ scale: 0.99 }] },
  buttonText: { color: "#FFFFFF", fontSize: 15, fontWeight: "800" },
  buttonArrow: { color: "#FFFFFF", fontSize: 20, fontWeight: "400" },
  helper: { color: colors.muted, fontSize: 11, textAlign: "center", lineHeight: 17, marginTop: 5 },
  bottom: { alignItems: "center", gap: 6, paddingTop: 15 },
  bottomText: { color: "#8799AD", fontSize: 9, fontWeight: "800", letterSpacing: 1.4 },
  bottomSub: { color: "#A2AFBD", fontSize: 10 }
});